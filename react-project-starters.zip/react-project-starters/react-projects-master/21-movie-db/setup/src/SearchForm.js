import React from 'react'
import { useGlobalContext } from './context'
const SearchForm = () => {
  return <h2>search component</h2>
}

export default SearchForm
