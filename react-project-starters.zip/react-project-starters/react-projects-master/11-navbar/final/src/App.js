import React from 'react';
import Navbar from './Navbar';
function App() {
  return (
    <>
      <Navbar></Navbar>
    </>
  );
}

export default App;
